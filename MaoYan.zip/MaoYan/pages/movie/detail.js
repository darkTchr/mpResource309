Page({
  spread: function () {

    this.setData({
      spread: !this.data.spread
    })
  },
  preview: function () {
    // wx.preview
  }
});